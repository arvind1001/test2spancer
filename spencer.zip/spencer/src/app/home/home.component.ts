import { Component, OnInit, ViewChild } from '@angular/core';
import { HeaderComponent } from '../header/header.component';
import { AppserviceService } from '../service/appservice.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  constructor(public service:AppserviceService) {
  }
  header={
    noSearch:true,
    isSearch:true,
  }
  showHeaderMsg='Change Header With Search bar';
  
  ngOnInit() {
    this.toggleHeader()
  }
  toggleHeader(){  
    if(this.showHeaderMsg =='Change Header With Search bar'){
      this.header.noSearch=false;
      this.header.isSearch=true;
      this.showHeaderMsg='Change Header Without Search bar';
    }else{
      this.showHeaderMsg='Change Header With Search bar'
      this.header.noSearch=true;
      this.header.isSearch=false;
    }
    this.service.changeHeader(this.header)
  }
}
