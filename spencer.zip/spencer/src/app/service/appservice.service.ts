import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AppserviceService {
  private headerObject = new BehaviorSubject<Object>({});
  headerInfo = this.headerObject.asObservable();
  constructor() { }
  changeHeader(headerObject) {
    this.headerObject.next(headerObject);
  }
}
