import { Component, OnInit } from '@angular/core';
import { AppserviceService } from '../service/appservice.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  headerObject;
  isSearch;
  noSearch
  constructor(private service:AppserviceService) { 
      this.service.headerInfo.subscribe(res => {
      this.headerObject = res;
      this.noSearch =this.headerObject.noSearch;
    });
  }
  ngOnInit() {
  }

}
