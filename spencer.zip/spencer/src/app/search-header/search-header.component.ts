import { Component, OnInit } from '@angular/core';
import { AppserviceService } from '../service/appservice.service';

@Component({
  selector: 'app-search-header',
  templateUrl: './search-header.component.html',
  styleUrls: ['./search-header.component.css']
})
export class SearchHeaderComponent {
  headerObject;
  isSearch;
  noSearch
  constructor(private service:AppserviceService) { 
    this.isSearch=true;
      this.service.headerInfo.subscribe(res => {
      this.headerObject = res;
      this.isSearch =this.headerObject.isSearch;
     });
   }
}
